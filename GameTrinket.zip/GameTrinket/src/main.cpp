#include <stdio.h>
#include <glad/gl.h>
#include <GLFW/glfw3.h>
#include <iostream>


void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
}   

int main() {
	glfwInit();
	GLFWwindow* window = glfwCreateWindow(640, 480, "My Title", NULL, NULL);
	if (window == NULL)
	{
    		std::cout << "Failed to create GLFW window" << std::endl;
   		glfwTerminate();
    		return -1;
	}
	glfwMakeContextCurrent(window);
	printf("Hello, Opengl!");
	glViewport(0, 0, 800, 600);
	glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);  
	while(!glfwWindowShouldClose(window))
	{
    		glfwSwapBuffers(window);
    		glfwPollEvents();    
	}
	glfwTerminate();	
	return 0;
}
